<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    require_once "db_connection.php";

    $name = $_POST["name"];
    $password = $_POST["password"];
    $addressline = $_POST["addressline"];
    $postcode = $_POST["postcode"];
    $email = $_POST["email"];
    $telephone = $_POST["telephone"];

    $sql = "INSERT INTO users (name, password, addressline, postcode, email, telephone) 
            VALUES (:name, :password, :addressline, :postcode, :email, :telephone)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":name", $name);
    $stmt->bindParam(":password", $password);
    $stmt->bindParam(":addressline", $addressline);
    $stmt->bindParam(":postcode", $postcode);
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":telephone", $telephone);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        header("Location: thank_you.html");
        exit; 
    } else {
        echo "Registration failed. Please try again.";
    }
}
?>
