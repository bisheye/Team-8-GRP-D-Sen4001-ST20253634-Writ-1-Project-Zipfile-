<?php
session_start();

if (!isset($_SESSION["name"])) {
    header("Location: login.html");
    exit();
}

if(isset($_POST['caravan_id'])) {

    $caravan_id = $_POST['caravan_id'];

    $mysqli = new mysqli("localhost", "root", "", "rentmycar");

    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    $sql = "DELETE FROM vehicle_details WHERE vehicle_id = ?";

    $stmt = $mysqli->prepare($sql);

    $stmt->bind_param("i", $caravan_id);
    if ($stmt->execute()) {
        header("Location: user_dashboard.php");
    } else {
        header("Location: user_dashboard.php?error=1");
    }

    $stmt->close();
    $mysqli->close();
} else {
    header("Location: user_dashboard.php?error=1");
}
?>
