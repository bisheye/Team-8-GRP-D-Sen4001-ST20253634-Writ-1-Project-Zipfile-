<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caravan Summary - RentMyCaravan.io</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .caravan-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .caravan-image img {
            max-width: 300px;
            max-height: 200px;
            object-fit: cover;
            border-radius: 4px;
        }

        .caravan-details {
            margin-top: 10px;
            text-align: center;
        }

        .caravan-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            grid-gap: 20px;
        }
    </style>
</head>
<body>
    
    <header>
        <h1>Welcome to RentMyCaravan.io</h1>
    </header>

    <nav>
        <ul>
            <li><a href="welcome.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="login.html">Login</a></li>
            <li><a href="registration.html">Register</a></li>
            <li><a href="caravan_summary.php">Caravan Summary</a></li>
        </ul>
    </nav>

    <section id="The listings">
        <p>Here you will see all available listings for caravans that we have for renting.</p>
        <p>The descriptions will contain all necessary information for caravans, alongside the owners contact information.</p>
    </section>

    <section id="caravanSummary">
        <h2>Caravan Summary</h2>
        <div class="caravan-summary">
            <?php

            $mysqli = new mysqli("localhost", "root", "", "rentmycar");

            if ($mysqli->connect_error) {
                die("Connection failed: " . $mysqli->connect_error);
            }

            $sql = "SELECT vd.*, u.name, u.email FROM vehicle_details vd INNER JOIN users u ON vd.user_id = u.user_id";
            $result = $mysqli->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='caravan-item'>";
                    echo "<div class='caravan-image'><img src='" . $row["image_url"] . "' alt='Caravan Image'></div>";
                    echo "<div class='caravan-details'>";
                    echo "<h3>Posted By: " . $row["name"] . "</h3>";
                    echo "<p>Email: " . $row["email"] . "</p>";
                    echo "<p>Caravan Description: " . $row["description"] . "</p>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "No caravans found.";
            }

            $mysqli->close();
            ?>
        </div>
    </section>
</body>
</html>