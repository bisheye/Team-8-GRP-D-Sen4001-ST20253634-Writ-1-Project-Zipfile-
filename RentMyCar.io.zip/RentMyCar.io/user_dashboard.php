<?php
session_start();

if (!isset($_SESSION["name"])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION["user_id"]; 
$userCaravans = []; 

$mysqli = new mysqli("localhost", "root", "", "rentmycar");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "SELECT * FROM vehicle_details WHERE user_id = ?";
$stmt = $mysqli->prepare($sql);

$stmt->bind_param("i", $user_id);

$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $userCaravans[] = $row;
}

$stmt->close();
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - RentMyCaravan.io</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .caravan-image img {
            max-width: 200px; 
            max-height: 150px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to RentMyCaravan.io</h1>
    </header>
    

    <nav>
        <ul>
            <li><a href="welcome.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="caravan_summary.php">Caravan Summary</a></li>
            <li><a href="login.html">Logout and Return to Login</a></li>
        </ul>
    </nav>

    <section id="userDashboard">

        <h2>Welcome, <?php echo $_SESSION["name"]; ?>!</h2>

        <form id="addCaravanForm" method="post" action="add_caravan.php" enctype="multipart/form-data"> 
            <label for="description">Description:</label>
            <section id="The listings">
            <p>In this description ensure that you have included: The vehicle make, model, body type, fuel type, mileage, location, year, number of doors and any other information.   </p>
            </section>
            <textarea id="description" name="description" required></textarea>
            
            <label for="image">Upload Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>
            
            <button type="submit">Add Caravan</button>
        </form>
        
        <h3>Your Caravans</h3>
        <ul>
            <?php foreach ($userCaravans as $caravan) { ?>
                <li>
                    <p><?php echo $caravan['description']; ?></p>                    
                    <div class="caravan-image">
                        <img src="<?php echo $caravan['image_url']; ?>" alt="Caravan Image">
                    </div>               
                    <form method="post" action="delete_caravan.php">
                        <input type="hidden" name="caravan_id" value="<?php echo $caravan['vehicle_id']; ?>">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete this caravan?')">Delete</button>
                    </form>
                </li>
            <?php } ?>
        </ul>
    </section>
</body>
</html>
