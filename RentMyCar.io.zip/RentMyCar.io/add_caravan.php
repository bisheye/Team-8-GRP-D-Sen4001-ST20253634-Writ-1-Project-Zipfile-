<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "rentmycar");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $description = $mysqli->real_escape_string($_POST['description']);
    $user_id = $_SESSION["user_id"];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $check = getimagesize($_FILES["image"]["tmp_name"]);

    if ($check === false || !in_array($imageFileType, ["jpg", "png", "jpeg", "gif"]) || $_FILES["image"]["size"] > 5 * 1024 * 1024) {
    } elseif (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO vehicle_details (user_id, description, image_url) VALUES ('$user_id', '$description', '$target_file')";
        if ($mysqli->query($sql) === TRUE) {
            header("Location: caravan_summary.php");
            exit();
        }
    }
}

$mysqli->close();
?>
