<?php
session_start();

$mysqli = new mysqli("localhost", "root", "", "rentmycar");

if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $mysqli->real_escape_string($_POST['name']);
    $password = $mysqli->real_escape_string($_POST['password']);

    $query = "SELECT * FROM users WHERE name = '$name' AND PASSWORD = '$password'";
    $result = $mysqli->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION["name"] = $row['name'];
        $_SESSION["user_id"] = $row['user_id'];
        header("Location: user_dashboard.php");
    } else {

        header("Location: login.html");
    }
}

$mysqli->close();
?>
